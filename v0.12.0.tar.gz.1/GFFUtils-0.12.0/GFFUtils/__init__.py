# Current version of the library
__version__ = '0.12.0'

def get_version():
    """Returns a string with the current version of the library (e.g., "0.2.0")

    """
    return __version__
