GFFUtils/examples
=================

Set of example scripts and small example data sets for testing/demonstration
purposes.
